﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Make : MonoBehaviour
{
    public CraftingRecipe cr;
    public GameObject one;
    public GameObject two;
    public GameObject reward;
    int id;


    // Start is called before the first frame update
    void Start()
    {
        one = cr.itemOne;
        two = cr.itemTwo;
        reward = cr.award;
        id = cr.id;

    }

    // Update is called once per frame

}

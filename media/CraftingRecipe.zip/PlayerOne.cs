﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerOne : MonoBehaviour
{
    public Make make;
    List<GameObject> contacted = new List<GameObject>();


    // Start is called before the first frame update
    void Start()
    {

    }


    private void OnTriggerEnter(Collider other)
    {
        contacted.Add(other.gameObject);


    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            if (contacted != null)
            {
                if (contacted[0].name == make.one.name || contacted[0].name == make.two.name && (contacted[1].name == make.one.name || contacted[1].name == make.two.name)){
                    Instantiate(make.reward, transform.position, Quaternion.identity);
                }
            }
        }
    }
}

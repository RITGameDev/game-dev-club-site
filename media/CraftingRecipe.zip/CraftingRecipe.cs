﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class CraftingRecipe : ScriptableObject
{
    public GameObject itemOne;
    public GameObject itemTwo;
    public GameObject award;
    public int id;
  //  void GiveAward()
    //{
      //  Instantiate(award);
    //}
}
